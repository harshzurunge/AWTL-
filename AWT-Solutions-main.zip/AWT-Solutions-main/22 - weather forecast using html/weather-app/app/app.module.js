angular.module('weatherApp', ['ngRoute']);
