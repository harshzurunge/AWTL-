const questions = [
    {
      question: "What is the capital of France?",
      options: ["Berlin", "Madrid", "Paris", "Lisbon"],
      answer: "Paris"
    },
    {
      question: "Who wrote 'Hamlet'?",
      options: ["Charles Dickens", "J.K. Rowling", "William Shakespeare", "Mark Twain"],
      answer: "William Shakespeare"
    },
    {
      question: "What is the smallest planet in our solar system?",
      options: ["Mars", "Venus", "Mercury", "Jupiter"],
      answer: "Mercury"
    }
  ];
  
  export default questions;
  